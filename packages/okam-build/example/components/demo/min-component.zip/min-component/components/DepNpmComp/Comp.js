/**
 * @file Comp.js
 * @author xxx
 */

require('../dep');

Component({
    properties: {
        outText: {
            type: String,
            value: 'val'
        }
    },

    data: {
        innerText: 'min-component 包中有依赖第三方自定义组件的自定义组件'
    },

    methods: {}
});
