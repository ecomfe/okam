Component({
    properties: {
        outText: {
            type: String,
            value: 'val'
        }
    },

    data: {
        innerText: 'min-component 包中无其他依赖的另一个自定义组件'
    },

    methods: {}
});
