export default {
    name: 'min-component',

    arr: ['json', 'js', 'css', 'swan'],

    str: 'hello word'
};
