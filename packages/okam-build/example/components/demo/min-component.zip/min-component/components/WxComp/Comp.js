//index.js
const util = require('../utils/util.js');

Component({
    properties: {
        outText: {
            type: String,
            value: 'default value'
        }
    },
    data: {
        logs: ['xxx', 'bbbb']
    },
    ready: function () {
        this.setData({
            logs: (wx.getStorageSync('logs') || []).map(log => {
                return util.formatTime(new Date(log));
            })
        });
    },
    methods: {}
});
